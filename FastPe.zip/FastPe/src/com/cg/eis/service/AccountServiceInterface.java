package com.cg.eis.service;

public interface AccountServiceInterface {

}

package com.cg.eis.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.History;
import com.cg.eis.dao.AccountDao;
import com.cg.eis.exception.BankingException;

public class AccountService implements AccountServiceInterface {
	Account acc=new Account();
	AccountDao dao=new AccountDao();
	LocalDateTime n=LocalDateTime.now();
	Map<Double,Account>account=new HashMap<Double,Account>();
	Map<LocalDateTime,History>history1=new HashMap<LocalDateTime,History>();
	public void addAccIntoMap() {
		acc=new Account(17562548,"Manish Deshmukh","9881238864",24000,"1421316675");
		addNewAccount(acc);
		acc=new Account(17562456,"Abhijeet Deshmukh","9881643323",29000,"1421125652");
		addNewAccount(acc);
		acc=new Account(17562789,"Pratik Kumthekar","9887896545",31000,"1421651241");
		addNewAccount(acc);
	}
	public boolean checkAccountAvailable(int acc) {
		boolean b=dao.checkAccountAvailable(acc);
		return b;
	}
	public Map<Double, Account> displayAccountDetails(int acc_number) {
		account=dao.displayAccountDetails(acc_number);
		return account;
	}
	public void addNewAccount(Account account) {
		dao.addNewAccount(account);
	}
	public int deposit(int account_number,int amount) {
		int amountAfterDeposit=dao.deposit(account_number,amount);
		return amountAfterDeposit;
	}
	public int withdraw(int account_Number_check1, int amountWithdrawal) {
		int amountAfterWithdrawal=dao.withdraw(account_Number_check1,amountWithdrawal);
		return amountAfterWithdrawal;
	}
	public int getCurrentBalance(int account_Number_Check) {
		return dao.getCurrentBalance(account_Number_Check);
	}
	public String fundTransfer(int account_number, int reciever_account_number,int amount) {
		String str1=dao.fundTransfer(account_number,reciever_account_number,amount);
		return str1;
	}
	public boolean validateUserName(String Name) {
		boolean flag=Pattern.matches("[A-Za-z]+",Name);
		if(flag==false) {
			try {
				throw new BankingException("Only Character should be present in Name");
			} catch (BankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}
	public boolean validatePhoneNumber(String pNumber) {
		boolean flag=Pattern.matches("[[9|8|7]{1}[0-9]{9}]+",pNumber);
		if(flag==false) {
			try {
				throw new BankingException("Only Digits should be present in Phone Number");
			} catch (BankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}
	public boolean validateAdharNumber(String aNumber) {
		boolean flag=Pattern.matches("[0-9]{10}+",aNumber);
		if(flag==false) {
			try {
				throw new BankingException("Only Digits should be present in Adhaar Number");
			} catch (BankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}
	public boolean validateAddress(String address) {
		boolean flag=Pattern.matches("[A-Za-z]+",address);
		if(flag==false) {
			try {
				throw new BankingException("Only Character should be present in Address");
			} catch (BankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}
	public void addHistory(History hist) {
		dao.addHistory(hist);
	}
	public void displayHistory(int acc_number) {
		List<History>list=new ArrayList<History>();
		list=dao.displayHistory(acc_number);
		Iterator itr=list.iterator();
		while(itr.hasNext()) {
			History hist=(History) itr.next();
			if(hist.getTransType()==1) {
				System.out.println("Transaction Id:"+hist.getTransactionID()  + "Account Number: "+hist.getAccount_Number()+"  Deposit Amount: "+hist.getDeposit_amount()+"  Date: "+hist.getDepositDate());
			}
			if(hist.getTransType()==2) {
				System.out.println("Transaction Id:"+hist.getTransactionID()  + "Account Number: "+hist.getAccount_Number()+"  Withdraw Amount: "+hist.getWithdrawAmount()+"  Date: "+hist.getWithDrawDate());
			}
			if(hist.getTransType()==3) {
				System.out.println("Transaction Id:"+hist.getTransactionID()  + "Account Number: "+hist.getAccount_Number()+"  Reciever Account Number "+hist.getRecieverAccountNumber()+"  Amount Transfered: "+hist.getAmountTransfered()+"  Date: "+hist.getTransDate());
			}
			//System.out.println(itr.next());
		}
	}
}

package com.cg.eis.bean;
import java.time.LocalDateTime;
public class History {
	int account_Number;
	String account_HolderName;
	int deposit_amount;
	int withdrawAmount;
	double FaccountNumber;
	int RecieverAccountNumber;
	int amountTransfered;
	LocalDateTime DepositDate;
	LocalDateTime withDrawDate;
	LocalDateTime transDate;
	public LocalDateTime getTransDate() {
		return transDate;
	}
	public void setTransDate(LocalDateTime transDate) {
		this.transDate = transDate;
	}
	int transactionID;
	int transType;
	public int getTransType() {
		return transType;
	}
	public void setTransType(int transType) {
		this.transType = transType;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public int getWithdrawAmount() {
		return withdrawAmount;
	}
	public void setWithdrawAmount(int withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}
	public double getFaccountNumber() {
		return FaccountNumber;
	}
	public void setFaccountNumber(double faccountNumber) {
		FaccountNumber = faccountNumber;
	}
	public int getRecieverAccountNumber() {
		return RecieverAccountNumber;
	}
	public void setRecieverAccountNumber(int recieverAccountNumber) {
		RecieverAccountNumber = recieverAccountNumber;
	}
	public int getAmountTransfered() {
		return amountTransfered;
	}
	public void setAmountTransfered(int amountTransfered) {
		this.amountTransfered = amountTransfered;
	}
	public LocalDateTime getWithDrawDate() {
		return withDrawDate;
	}
	public void setWithDrawDate(LocalDateTime withDrawDate) {
		this.withDrawDate = withDrawDate;
	}
	public LocalDateTime getDepositDate() {
		return DepositDate;
	}
	public void setDepositDate(LocalDateTime depositDate) {
		DepositDate = depositDate;
	}
	
	public int getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(int account_Number) {
		this.account_Number = account_Number;
	}
	public String getAccount_HolderName() {
		return account_HolderName;
	}
	public void setAccount_HolderName(String account_HolderName) {
		this.account_HolderName = account_HolderName;
	}
	public int getDeposit_amount() {
		return deposit_amount;
	}
	public void setDeposit_amount(int deposit_amount) {
		this.deposit_amount = deposit_amount;
	}
	@Override
	public String toString() {
		return "History [account_Number=" + account_Number + ", account_HolderName=" + account_HolderName
				+ ", deposit_amount=" + deposit_amount + ", withdrawAmount=" + withdrawAmount + ", FaccountNumber="
				+ FaccountNumber + ", RecieverAccountNumber=" + RecieverAccountNumber + ", amountTransfered="
				+ amountTransfered + ", DepositDate=" + DepositDate + ", withDrawDate="
				+ withDrawDate + ", transactionID=" + transactionID + "]";
	}
}
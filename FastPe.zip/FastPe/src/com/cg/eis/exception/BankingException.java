package com.cg.eis.exception;

public class BankingException extends Exception {
	public BankingException(String arg) {
		super(arg);
	}
}

package com.cg.eis.main;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.History;
import com.cg.eis.exception.BankingException;
import com.cg.eis.service.AccountService;

public class Client {

	public static void main(String[] args) {
		History hs=null;
		AccountService as=new AccountService();
		int i;
		as.addAccIntoMap();
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("Do you had Account??\t Press 1\nDo you want to create account??\tPress 2");
		int n=sc.nextInt();
		switch(n) {
		case 1:{
				System.out.println("Enter Account Number: ");
				int acc_number=sc.nextInt();
				boolean b=as.checkAccountAvailable(acc_number);
				if(b==true) {
					boolean flag =true;
				while(flag) {
					System.out.println("Enter Your Choice: \n1.Deposit Amount\n2.Withdrawal Amount\n3.Display\n4.Get Balance\n5.Fund Transfer\n6.Transaction History\n7.For Main Menu.");
					int choice=sc.nextInt();
					switch(choice){
					case 1:{
						//For Deposit
						hs=new History();
						System.out.println("You want to deposit amount in your account...");
						int account_Number_check=acc_number;
						hs.setAccount_Number(account_Number_check);
						System.out.println("Now enter the amount for deposit");
						int amount=sc.nextInt();
						hs.setDeposit_amount(amount);
						LocalDateTime now=LocalDateTime.now();
						hs.setDepositDate(now);
						int amountAfterDeposit=as.deposit(account_Number_check,amount);
						System.out.println("New Balance: "+amountAfterDeposit);
						int max=9999999;
						int min=1111111;
						int range=max-min-1;
						int transcId=(int)(Math.random()*range)+min;
						hs.setTransactionID(transcId);
						hs.setTransType(1);
						as.addHistory(hs);
						break;
						}
					case 2:{
						//For Withdrawal
						hs=new History();
						System.out.println("You want to withdraw amount in your account...");
						int account_Number_check1=acc_number;
						hs.setAccount_Number(account_Number_check1);
						System.out.println("Now enter the amount for Withdrawal");
						int amountWithdrawal=sc.nextInt();
						hs.setWithdrawAmount(amountWithdrawal);
						LocalDateTime now=LocalDateTime.now();
						hs.setWithDrawDate(now);
						int amountAfterWithdraw=as.withdraw(account_Number_check1,amountWithdrawal);
						System.out.println("New Balance: "+amountAfterWithdraw);
						int max=9999999;
						int min=1111111;
						int range=max-min-1;
						int transcId=(int)(Math.random()*range)+min;
						hs.setTransactionID(transcId);
						hs.setTransType(2);
						as.addHistory(hs);
						break;
						}
					case 3:{
						//For Display
						System.out.println("Accounts Detail: ");
						System.out.println(as.displayAccountDetails(acc_number));
						break;
						}
					case 4:{
						//Get balance
						int account_Number_Check=acc_number;
						int balance=as.getCurrentBalance(account_Number_Check);
						System.out.println("Current Balance: "+balance);
						break;
						}
					case 5:{
							//Fund Transfer
						    hs=new History();
							int account_number,reciever_account_number,amount;
							account_number=acc_number;
							hs.setAccount_Number(account_number);
							System.out.println("Enter Receiver Account Number: ");
							reciever_account_number=sc.nextInt();
							hs.setRecieverAccountNumber(reciever_account_number);
							System.out.println("Enter Amount to Transfer: ");
							amount=sc.nextInt();
							hs.setAmountTransfered(amount);
							int max=9999999;
							int min=1111111;
							int range=max-min-1;
							int transcId=(int)(Math.random()*range)+min;
							LocalDateTime now=LocalDateTime.now();
							hs.setTransDate(now);
							hs.setTransactionID(transcId);
							hs.setTransType(3);
							as.addHistory(hs);
							String str=as.fundTransfer(account_number,reciever_account_number,amount);
							System.out.println(str);
							break;
						}
					case 6:{
								//Print Transaction
								System.out.println("Enter The account Number For Print Transaction....");
								int account_number=sc.nextInt();
								as.displayHistory(account_number);
							}
					case 7:{
						//For Main Menu
						flag =false;
					}
					  }
				}
				}
				else {
					try {
						throw new BankingException("Incorrect Account Number");
					} catch (BankingException e) {
						e.printStackTrace();
					}
					//System.out.println("Incorrect Account Number");
					}
				break;
				}
		case 2:{
				Account account=new Account();
				int max=9999999;
				int min=1111111;
				int range=max-min-1;
				int account_number=(int)(Math.random()*range)+min;
				System.out.println("Add the following Account Detail for creating of new Account....");
				account.setAccount_Number(account_number);
				//h[i].setAccount_Number(account_number);
				boolean nameFlag1=true;
				while(nameFlag1) {
				System.out.println("Enter Account Holder Name: ");
				String account_HolderName=sc.next();
				boolean nameFlag=as.validateUserName(account_HolderName);
				if(nameFlag==true){
					account.setAccount_HolderName(account_HolderName);
					nameFlag1=false;
					break;
				}
				}
				//h[i].setAccount_HolderName(account_HolderName);
				boolean phoneFlag=true;
				while(phoneFlag) {
				System.out.println("Enter Phone Number: ");
				String phone_Number=sc.next();
				boolean pF=as.validatePhoneNumber(phone_Number);
				if(pF==true) {
				account.setPhone_Number(phone_Number);
				phoneFlag=false;
				break;
				}
				}
				boolean adhaarN=true;
				while(adhaarN) {
				System.out.println("Enter Aadhar Number: ");
				String aadhar_Number=sc.next();
				boolean aF=as.validateAdharNumber(aadhar_Number);
				if(aF==true) {
				account.setAadhar_number(aadhar_Number);
				adhaarN=false;
				break;
				}
				}
				System.out.println("your account number is: "+account_number);
				LocalDateTime now=LocalDateTime.now();
				//h[i].setDate(now);
				as.addNewAccount(account);
				}
			}
		
		}
	}

}
